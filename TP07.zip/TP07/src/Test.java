public class Test {

    private static void chargerDonneesEtudiants(String path){
        // A compléter
    }

    private static void chargerDonneesNotes(String path){
        // A compléter
    }

    private static void afficheMoyenneEtudiant(){
        // A compléter
    }

    private static void afficheNoteEtudiant(Etudiant e){
        // A compléter
    }

    private static void afficheMoyenneParMatiere(){
        // A compléter
    }

    public static void main(String[] args) {
        String localDir = System.getProperty("user.dir");
        if(System.getProperty("os.name").contains("Windows")){
            chargerDonneesEtudiants(localDir + "\\src\\etudiants.csv");
            chargerDonneesNotes(localDir + "\\src\\notes.csv");
        }else{
            chargerDonneesEtudiants(localDir + "/src/etudiants.csv");
            chargerDonneesNotes(localDir + "/src/notes.csv");
        }

        afficheMoyenneEtudiant();
        System.out.println();
        afficheNoteEtudiant(new Etudiant("Cerizo","Cecilia"));
        System.out.println();
        afficheMoyenneParMatiere();
    }
}
